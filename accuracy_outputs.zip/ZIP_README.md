The name of the output files in this archive, denote the specifications of the corresponding network.
They contain both the information for **1. Network Architecture**, **2. Network Hyperparameters**. 
The network architecture consists of two parts, specifying the **base**, and the **extension** architecture (in case of extended networks). 
Hyperparameters should be identifiable within the file names without too much difficulty.
A general format of the file names and the corresponding network configurations are given below, but pinpointing the exact configuration from the file name might require some care and time, as keywords and formats might not seem obvious at first.  
***Keys*** 
- _regul_ stands for regularization
- _tanh, relu, smax, sigmoid_ are nonlinears
- _agg\_feat_ stands for "aggregate features", which is the number of nodes in the first layer of the final fc layers after the convolution (not applicable for the simple network).

Format of the output files, based on the **Prefix**:
## Prefixes
### "<extended_net>_": "reg_", "fcN_", "feat*_"
The corresponding extended net in the prefix with the baseline base (*simple*).
### "<base_net>_<extended_net>_": "diff\_fc_<extended_net>_", "two\_fc_<extended_net>_"
Same as above but with the other two base networks specified. The extended network architecture follows immediately after the base.
### "<base_net>_{nonlinear}_"
Output from only the base network without being extended.
